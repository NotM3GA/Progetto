package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Finestra extends JFrame {

	private static final long serialVersionUID = 1L;
	private Pannello contentPane;

	public Finestra() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,1300, 800);
		contentPane = new Pannello();
		contentPane.setBorder(new EmptyBorder(5, 5, 500, 500));
		setVisible(true);
		setContentPane(contentPane);
	}

}
