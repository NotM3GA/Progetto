package view;

import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class Pannello extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbedPane;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JLabel lblNewLabel;
	private final JLabel lblGestionaleAuto;
	private JComboBox comboBox;
	private JButton btn_Next;
	private JLabel lbl_Colore;
	private JLabel lblNewLabel_1;
	private JComboBox comboBox_1;

	/**
	 * Create the panel.
	 */
	public Pannello() {
		setLayout(null);

		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, 1300, 800);
		add(tabbedPane);

		// Pannello
		panel = new JPanel();
		tabbedPane.addTab("New tab", null, panel, null);
		panel.setLayout(null);

		ImageIcon lambo = new ImageIcon(
				"C:\\Users\\giave\\eclipse-workspace\\ProgettoGruppo\\src\\view\\lamborghini.jpg");

		btn_Next = new JButton("Next");
		btn_Next.setFont(new Font("Arial", Font.BOLD, 15));
		btn_Next.setBackground(new Color(192, 192, 192));
		btn_Next.setBounds(540, 300, 205, 21);
		panel.add(btn_Next);

		comboBox = new JComboBox<>();
		comboBox.setModel(new DefaultComboBoxModel<>(new String[] { ".: Seleziona Lamborghini :.", "Aventador", "Huracán", "Revuelto", "Urus", "Gallardo", "Murcièlago", "Diablo", "Jalpa", "Silhouette", "Countach" }));
		comboBox.setBackground(new Color(192, 192, 192));
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setFont(new Font("Arial", Font.BOLD, 15));
		comboBox.setBounds(495, 200, 300, 30);
		panel.add(comboBox);

		lblGestionaleAuto = new JLabel("Gestionale Autofficina");
		lblGestionaleAuto.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblGestionaleAuto.setHorizontalAlignment(SwingConstants.CENTER);
		lblGestionaleAuto.setForeground(new Color(255, 255, 255));
		lblGestionaleAuto.setBounds(89, 75, 1100, 36);
		panel.add(lblGestionaleAuto);

		lblNewLabel = new JLabel(lambo);
		lblNewLabel.setBounds(0, 0, 1300, 800);
		panel.add(lblNewLabel);

		// Pannello 1
		panel_1 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_1, null);
		panel_1.setLayout(null);

		lbl_Colore = new JLabel("Selezionare il Colore ");
		lbl_Colore.setForeground(new Color(255, 255, 255));
		lbl_Colore.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Colore.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl_Colore.setBounds(89, 75, 1100, 36);
		panel_1.add(lbl_Colore);

		ImageIcon sfondo = new ImageIcon("C:\\Users\\giave\\eclipse-workspace\\ProgettoGruppo\\src\\view\\sfondo.jpg");
		lblNewLabel = new JLabel(sfondo);
		lblNewLabel.setBounds(0, 0, 1300, 800);
		panel_1.add(lblNewLabel);

		// Pannello 2
		panel_2 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_2, null);
		panel_2.setLayout(null);

		lblNewLabel_1 = new JLabel("Selezionare le Modifiche");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(89, 75, 1100, 36);
		panel_2.add(lblNewLabel_1);

		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {".:Modifiche Disponibili:.", "Kit Mansory", "Kit SottoParaurti", "Kit Spoiler", "Kit Minigonne", "Kit Scarico", "Kit Lama sottoporta"}));
		comboBox_1.setBackground(new Color(192, 192, 192));
		comboBox_1.setForeground(new Color(0, 0, 0));
		comboBox_1.setFont(new Font("Arial", Font.BOLD, 15));
		comboBox_1.setBounds(495, 200, 300, 30);
		panel_2.add(comboBox_1);

		lblNewLabel = new JLabel(sfondo);
		lblNewLabel.setBounds(0, 0, 1300, 800);
		panel_2.add(lblNewLabel);

		// Pannello 3
		panel_3 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_3, null);

		lblNewLabel = new JLabel(sfondo);
		lblNewLabel.setBounds(0, 10, 1300, 800);
		panel_3.add(lblNewLabel);

		add(tabbedPane, BorderLayout.CENTER);

	}
	
	public String ComboboxSelezionato() {
		return (String) comboBox.getSelectedItem();
		
	}
	

	public String ComboboxSelezionato1() {
		return (String) comboBox_1.getSelectedItem();
		
	}
}
