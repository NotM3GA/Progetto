/**
 * 
 */
/**
 * 
 */
module ProgettoGruppo {
	requires java.desktop;
}