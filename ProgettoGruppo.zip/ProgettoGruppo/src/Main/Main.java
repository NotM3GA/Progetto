package Main;

import control.Controller;
import view.Finestra;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Finestra f = new Finestra();
		Controller c = new Controller();
		
	}

}
