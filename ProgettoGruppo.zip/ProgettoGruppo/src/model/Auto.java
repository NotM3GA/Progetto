package model;

public class Auto {
	private String colore;
	private float prezzo;
	private String modello;
	private Boolean elaborato;
	private String numeroPorte;
	private String numeroPosti;
	private int cc;
	private int cv;

	public Auto(String colore, float prezzo, String modello, Boolean elaborato, String numeroPorte, String numeroPosti,
			int cc, int cv) {
		super();
		this.colore = colore;
		this.prezzo = prezzo;
		this.modello = modello;
		this.elaborato = elaborato;
		this.numeroPorte = numeroPorte;
		this.numeroPosti = numeroPosti;
		this.cc = cc;
		this.cv = cv;
	}

	public String getColore() {
		return colore;
	}

	public void setColore(String colore) {
		this.colore = colore;
	}

	public float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public Boolean getElaborato() {
		return elaborato;
	}

	public void setElaborato(Boolean elaborato) {
		this.elaborato = elaborato;
	}

	public String getNumeroPorte() {
		return numeroPorte;
	}

	public void setNumeroPorte(String numeroPorte) {
		this.numeroPorte = numeroPorte;
	}

	public String getNumeroPosti() {
		return numeroPosti;
	}

	public void setNumeroPosti(String numeroPosti) {
		this.numeroPosti = numeroPosti;
	}

	public int getCc() {
		return cc;
	}

	public void setCc(int cc) {
		this.cc = cc;
	}

	public int getCv() {
		return cv;
	}

	public void setCv(int cv) {
		this.cv = cv;
	}

	@Override
	public String toString() {
		return "Auto [colore=" + colore + ", prezzo=" + prezzo + ", modello=" + modello + ", elaborato=" + elaborato
				+ ", numeroPorte=" + numeroPorte + ", numeroPosti=" + numeroPosti + ", cc=" + cc + ", cv=" + cv + "]";
	}

}
