package model;

public class Officina {

}
